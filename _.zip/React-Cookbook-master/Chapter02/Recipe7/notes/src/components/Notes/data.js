export const notes1 = [
  {
    title: 'Note 1',
    content: 'Content for Note 1'
  },
  {
    title: 'Note 2',
    content: 'Content for Note 2'
  },
  {
    title: 'Note 3',
    content: 'Content for Note 3'
  }
];

export const notes2 = [
  {
    title: 'Note 4',
    content: 'Content for Note 4'
  },
  {
    title: 'Note 5',
    content: 'Content for Note 5'
  },
  {
    title: 'Note 6',
    content: 'Content for Note 6'
  }
];
