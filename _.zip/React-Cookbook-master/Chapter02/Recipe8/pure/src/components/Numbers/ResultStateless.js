import React from 'react';

const Result = props => <li>{props.result}</li>;

export default Result;
