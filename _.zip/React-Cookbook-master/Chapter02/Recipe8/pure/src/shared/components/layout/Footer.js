import React from 'react';

const Footer = () => (
  <footer style={{ marginTop: '100px' }}>
    &copy; Codejobs {(new Date()).getFullYear()}
  </footer>
);

export default Footer;
