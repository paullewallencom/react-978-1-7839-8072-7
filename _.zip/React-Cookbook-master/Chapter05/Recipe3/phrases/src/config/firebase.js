export const fbConfig = {
  ref: 'phrases',
  app: {
    apiKey: 'AIzaSyASppMJh_6QIGTeXVBeYszzz7iTNTADxRU',
    authDomain: 'codejobs-2240b.firebaseapp.com',
    databaseURL: 'https://codejobs-2240b.firebaseio.com',
    projectId: 'codejobs-2240b',
    storageBucket: 'codejobs-2240b.appspot.com',
    messagingSenderId: '278058258089'
  }
};
